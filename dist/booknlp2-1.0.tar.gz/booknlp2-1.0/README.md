# booknlp2
A successor to booknlp, aiming to fix bugs and improve model performance
